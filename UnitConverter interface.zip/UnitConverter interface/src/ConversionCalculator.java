import java.util.Scanner;

public class ConversionCalculator {
    public static void main (String[] args) {

    }
}
