from tkinter import *

def MaiorMenor(idade):
    entrada.delete(0, END)
    saida.delete(0.0, END)
    try:
        numero = int(idade)
        if numero < 18:
            saida.insert(END, f"Com {numero} anos, você ainda é menor...")
        else:
            saida.insert(END, f"Com {numero} anos, você já é maior!")
    except ValueError:
        saida.insert(END, f"Erro! '{idade}' não é um número, tente novamente!")

root = Tk()

root.title("Checar idade")

Label(root, text="Quantos anos você tem?").pack()
entrada = Entry(root, width=30)
entrada.pack()

botao = Button(root, text="Maior ou menor?", command=lambda: MaiorMenor(entrada.get()))
botao.pack()

saida = Text(root, width=50)
saida.pack()

root.mainloop()

